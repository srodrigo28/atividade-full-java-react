package com.treina.dev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppTreinaApplicationTests {

	@Test
	void contextLoads() {
	}

}
