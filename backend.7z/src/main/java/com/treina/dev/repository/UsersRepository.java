package com.treina.dev.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.treina.dev.model.Users;

@Repository
public interface UsersRepository extends CrudRepository<Users, Long> {}
