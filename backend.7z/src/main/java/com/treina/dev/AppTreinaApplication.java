package com.treina.dev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppTreinaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppTreinaApplication.class, args);
	}

}
