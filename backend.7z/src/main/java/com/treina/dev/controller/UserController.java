package com.treina.dev.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.treina.dev.model.Users;
import com.treina.dev.repository.UsersRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api/v1/users")
public class UserController {
    
    @Autowired
    private UsersRepository userRepository;

    @CrossOrigin("*")
    @PostMapping 
    public Users cadastrar(@RequestBody @Valid Users obj){
        return userRepository.save(obj);
    }

    @CrossOrigin("*") 
    @GetMapping
    public Iterable<Users> listar(){
        return userRepository.findAll();
    }

    @CrossOrigin("*") 
    @GetMapping("/{id}") // 3 Listar um
    public Optional<Users> listarUm(@PathVariable Long id){
        return userRepository.findById(id);
    }

    @CrossOrigin("*") 
    @DeleteMapping("/{id}") // 4 Deletar
    public ResponseEntity<Void> deletarAluno(@PathVariable Long id){
        userRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @CrossOrigin("*") 
    @PutMapping // 5 Atualizar
    public Users atualizarAluno(@RequestBody @Valid Users obj){
        if(obj.getId() > 0){
            return userRepository.save(obj);
        } return obj;
    }
}
