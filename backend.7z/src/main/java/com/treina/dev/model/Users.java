package com.treina.dev.model;

import java.time.Instant;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity(name = "users")
public class Users {
    
    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50)
    @NotBlank( message = "Nome precisa ser preenchido")
    private String nome;

    @Column(length = 50)
    @NotBlank( message = "E-mail precisa ser preenchido")
    private String email;

    @Column(length = 50)
    @NotBlank( message = "Senha precisa ser preenchido")
    private String senha;

    @CreationTimestamp
    private Instant creationTimestamp;

     @UpdateTimestamp
    private Instant updateTimestamp;
}
