import { useState } from "react"

export function Login(){
    const [email, setEmail] = useState("")
    const [senha, setSenha] = useState("")
    const [emailErro, setEmailErro] = useState("")
    const [senhaErro, setSenhaErro] = useState("")
  
    const valida = (e: any) =>{
      e.preventDefault()
  
      if( email == "" ){
          setEmailErro("Validar e-mail")
      }else if( senha == ""){
          setEmailErro("")
          setSenhaErro("Validar senha")
      }else if( email == "admin@admin" && senha == "admin"){
          setSenhaErro("")
          setEmailErro("")
  
          alert("Carregando página ...")  
      }else{
        setSenhaErro("")
        setEmailErro("")
  
        console.log("validado ...")
      }
    }

    return(
        <div className="bg-gray-600 h-screen flex">
            <div className="bg-slate-400 rounded-xl container m-auto flex flex-col p-10 w-72 h-72 ">
                <label htmlFor="email">E-mail</label>
                <input type="text" id="email" className="rounded-md p-2 outline-none" value={email} onChange={ e => setEmail(e.target.value)}/>
                <small className="mb-1 text-red-600 font-bold text-center tracking-wide">{emailErro}</small>
                
                <label htmlFor="senha">Senha</label>
                <input type="password" id="senha" className="rounded-md p-2 outline-none" value={senha} onChange={ e => setSenha(e.target.value)}/>
                <small className="mb-3 text-center text-red-600 font-bold tracking-wide">{senhaErro}</small>

                <div className="group-button flex gap-4">
                <button className="bg-green-500 p-2 w-32 rounded-md" onClick={valida}>Entrar</button>
                <button className="bg-cyan-500 p-2 w-32 rounded-md">Cadastro</button>
                </div>
            </div>
        </div>
    )
}