#### Configurando application TailWind CSS
```
https://tailwindcss.com/docs/guides/vite
```

#### Implementando rotas
```
https://github.com/srodrigo28/carteira-react-maio/blob/main/src/routes/app.routes.tsx
```

#### Axios
```
https://github.com/srodrigo28/react-dt-finances/blob/main/src/components/Dashbord/TransactionTable/index.tsx
```